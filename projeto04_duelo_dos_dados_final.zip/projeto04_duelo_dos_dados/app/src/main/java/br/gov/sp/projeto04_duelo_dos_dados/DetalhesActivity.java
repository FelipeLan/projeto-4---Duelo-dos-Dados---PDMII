package br.gov.sp.projeto04_duelo_dos_dados;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class DetalhesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detalhes);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainDetalhes), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView txtDetalhes = findViewById(R.id.txtDetalhes);
        Button btnVoltar = findViewById(R.id.btnVoltarDetalhes);

        String nome = getIntent().getStringExtra("nomeJogador");
        int jogador1 = getIntent().getIntExtra("valorJogador1", 0);
        int jogador2 = getIntent().getIntExtra("valorJogador2", 0);
        int totalJogador = getIntent().getIntExtra("totalJogador", 0);
        int computador1 = getIntent().getIntExtra("valorComputador1", 0);
        int computador2 = getIntent().getIntExtra("valorComputador2", 0);
        int totalComputador = getIntent().getIntExtra("totalComputador", 0);
        String resultado = getIntent().getStringExtra("resultadoRodada");
        String classificacao = getIntent().getStringExtra("classificacao");
        String dupla = getIntent().getStringExtra("informacaoDupla");

        String detalhes = "JOGADOR\n"
                + "Nome: " + nome + "\n"
                + "Dado 1: " + jogador1 + "\n"
                + "Dado 2: " + jogador2 + "\n"
                + "Total: " + totalJogador + "\n\n"
                + "COMPUTADOR\n"
                + "Dado 1: " + computador1 + "\n"
                + "Dado 2: " + computador2 + "\n"
                + "Total: " + totalComputador + "\n\n"
                + "RESULTADO\n" + resultado + "\n\n"
                + "CLASSIFICAÇÃO DA JOGADA\n" + classificacao + "\n\n"
                + "DUPLA\n" + dupla;

        txtDetalhes.setText(detalhes);

        btnVoltar.setOnClickListener(v -> finish());
    }
}
