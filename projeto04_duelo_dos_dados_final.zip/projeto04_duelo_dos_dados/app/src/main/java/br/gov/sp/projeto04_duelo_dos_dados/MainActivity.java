package br.gov.sp.projeto04_duelo_dos_dados;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText campoNome;
    private ImageView dadoJogador1, dadoJogador2, dadoComputador1, dadoComputador2;
    private TextView txtPlacar, txtTotalJogador, txtTotalComputador, txtResultado, txtDupla;
    private Switch switchMelhorDe3;
    private Button btnJogar, btnDetalhes, btnRegras, btnNovaPartida;

    private final Random random = new Random();

    private int valorJogador1 = 1;
    private int valorJogador2 = 1;
    private int valorComputador1 = 1;
    private int valorComputador2 = 1;
    private int totalJogador = 0;
    private int totalComputador = 0;
    private int placarJogador = 0;
    private int placarComputador = 0;

    private String resultadoRodada = "";
    private String classificacao = "";
    private String informacaoDupla = "Nenhuma dupla nesta rodada.";
    private boolean houveJogada = false;
    private boolean partidaEncerrada = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        inicializarViews();
        configurarBotoes();
        atualizarTelaInicial();
    }

    private void inicializarViews() {
        campoNome = findViewById(R.id.campoNome);
        dadoJogador1 = findViewById(R.id.dadoJogador1);
        dadoJogador2 = findViewById(R.id.dadoJogador2);
        dadoComputador1 = findViewById(R.id.dadoComputador1);
        dadoComputador2 = findViewById(R.id.dadoComputador2);

        txtPlacar = findViewById(R.id.txtPlacar);
        txtTotalJogador = findViewById(R.id.txtTotalJogador);
        txtTotalComputador = findViewById(R.id.txtTotalComputador);
        txtResultado = findViewById(R.id.txtResultado);
        txtDupla = findViewById(R.id.txtDupla);

        switchMelhorDe3 = findViewById(R.id.switchMelhorDe3);
        btnJogar = findViewById(R.id.btnJogar);
        btnDetalhes = findViewById(R.id.btnDetalhes);
        btnRegras = findViewById(R.id.btnRegras);
        btnNovaPartida = findViewById(R.id.btnNovaPartida);
    }

    private void configurarBotoes() {
        btnJogar.setOnClickListener(v -> jogarRodada());

        btnDetalhes.setOnClickListener(v -> abrirDetalhes());

        btnRegras.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, RegrasActivity.class);
            startActivity(intent);
        });

        btnNovaPartida.setOnClickListener(v -> novaPartida());

        switchMelhorDe3.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (partidaEncerrada) {
                return;
            }
            // Trocar o modo no meio da partida começa um novo placar para evitar
            // misturar uma partida normal com uma partida Melhor de 3.
            if (houveJogada && (placarJogador > 0 || placarComputador > 0)) {
                novaPartida();
                switchMelhorDe3.setChecked(isChecked);
            }
        });
    }

    private void jogarRodada() {
        String nome = campoNome.getText().toString().trim();

        if (nome.isEmpty()) {
            campoNome.setError("Informe seu nome antes de jogar.");
            Toast.makeText(this, "Digite seu nome para iniciar a partida.", Toast.LENGTH_SHORT).show();
            campoNome.requestFocus();
            return;
        }

        if (partidaEncerrada) {
            Toast.makeText(this, "A partida terminou. Clique em NOVA PARTIDA.", Toast.LENGTH_SHORT).show();
            return;
        }

        valorJogador1 = sortearDado();
        valorJogador2 = sortearDado();
        valorComputador1 = sortearDado();
        valorComputador2 = sortearDado();

        atualizarImagem(dadoJogador1, valorJogador1);
        atualizarImagem(dadoJogador2, valorJogador2);
        atualizarImagem(dadoComputador1, valorComputador1);
        atualizarImagem(dadoComputador2, valorComputador2);

        totalJogador = valorJogador1 + valorJogador2;
        totalComputador = valorComputador1 + valorComputador2;

        txtTotalJogador.setText("Total: " + totalJogador);
        txtTotalComputador.setText("Total: " + totalComputador);

        if (totalJogador > totalComputador) {
            resultadoRodada = "🏆 " + nome + " venceu a rodada!";
            placarJogador++;
        } else if (totalComputador > totalJogador) {
            resultadoRodada = "💻 Computador venceu a rodada!";
            placarComputador++;
        } else {
            resultadoRodada = "🤝 Empate!";
        }

        classificacao = classificarJogada(totalJogador);
        informacaoDupla = verificarDuplas();

        txtResultado.setText(resultadoRodada);
        txtDupla.setText(informacaoDupla);
        atualizarPlacar();

        houveJogada = true;
        btnDetalhes.setEnabled(true);

        if (switchMelhorDe3.isChecked() && (placarJogador >= 2 || placarComputador >= 2)) {
            partidaEncerrada = true;
            if (placarJogador >= 2) {
                txtResultado.setText("🏆 " + nome + " venceu a PARTIDA Melhor de 3!");
            } else {
                txtResultado.setText("💻 Computador venceu a PARTIDA Melhor de 3!");
            }
            btnJogar.setEnabled(false);
            switchMelhorDe3.setEnabled(false);
            Toast.makeText(this, "Partida encerrada! Clique em NOVA PARTIDA.", Toast.LENGTH_LONG).show();
        }
    }

    private int sortearDado() {
        return random.nextInt(6) + 1;
    }

    private void atualizarImagem(ImageView imageView, int valor) {
        int[] imagens = {
                R.drawable.dado_1,
                R.drawable.dado_1,
                R.drawable.dado_2,
                R.drawable.dado_3,
                R.drawable.dado_4,
                R.drawable.dado_5,
                R.drawable.dado_6
        };
        imageView.setImageResource(imagens[valor]);
    }

    private String verificarDuplas() {
        boolean duplaJogador = valorJogador1 == valorJogador2;
        boolean duplaComputador = valorComputador1 == valorComputador2;

        if (duplaJogador && duplaComputador) {
            return "🎲 DUPLA dos dois participantes!";
        } else if (duplaJogador) {
            return "🎲 " + campoNome.getText().toString().trim() + " obteve uma DUPLA!";
        } else if (duplaComputador) {
            return "🎲 Computador obteve uma DUPLA!";
        }
        return "Nenhuma dupla nesta rodada.";
    }

    private String classificarJogada(int total) {
        if (total >= 11) {
            return "Excelente";
        } else if (total >= 8) {
            return "Alta";
        } else if (total >= 5) {
            return "Média";
        } else {
            return "Baixa";
        }
    }

    private void atualizarPlacar() {
        txtPlacar.setText("PLACAR  •  " + campoNome.getText().toString().trim()
                + ": " + placarJogador + "   |   Computador: " + placarComputador);
    }

    private void atualizarTelaInicial() {
        txtPlacar.setText("PLACAR  •  Jogador: 0   |   Computador: 0");
        txtTotalJogador.setText("Total: -");
        txtTotalComputador.setText("Total: -");
        txtResultado.setText("Faça sua primeira jogada!");
        txtDupla.setText("Nenhuma rodada realizada.");
        btnDetalhes.setEnabled(false);
    }

    private void novaPartida() {
        placarJogador = 0;
        placarComputador = 0;
        totalJogador = 0;
        totalComputador = 0;
        houveJogada = false;
        partidaEncerrada = false;
        resultadoRodada = "";
        classificacao = "";
        informacaoDupla = "Nenhuma rodada realizada.";

        dadoJogador1.setImageResource(R.drawable.dado_1);
        dadoJogador2.setImageResource(R.drawable.dado_1);
        dadoComputador1.setImageResource(R.drawable.dado_1);
        dadoComputador2.setImageResource(R.drawable.dado_1);

        atualizarTelaInicial();
        btnJogar.setEnabled(true);
        switchMelhorDe3.setEnabled(true);

        Toast.makeText(this, "Nova partida iniciada!", Toast.LENGTH_SHORT).show();
    }

    private void abrirDetalhes() {
        if (!houveJogada) {
            Toast.makeText(this, "Faça uma jogada antes de consultar os detalhes.", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(MainActivity.this, DetalhesActivity.class);
        intent.putExtra("nomeJogador", campoNome.getText().toString().trim());
        intent.putExtra("valorJogador1", valorJogador1);
        intent.putExtra("valorJogador2", valorJogador2);
        intent.putExtra("totalJogador", totalJogador);
        intent.putExtra("valorComputador1", valorComputador1);
        intent.putExtra("valorComputador2", valorComputador2);
        intent.putExtra("totalComputador", totalComputador);
        intent.putExtra("resultadoRodada", resultadoRodada);
        intent.putExtra("classificacao", classificacao);
        intent.putExtra("informacaoDupla", informacaoDupla);
        startActivity(intent);
    }
}
